module pe {
	opens main;
	requires javafx.graphics;
	requires javafx.controls;
}